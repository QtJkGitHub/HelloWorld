<div align="center"> 
	<img src="alipay.png" alt="" width="225"/>
</div>
